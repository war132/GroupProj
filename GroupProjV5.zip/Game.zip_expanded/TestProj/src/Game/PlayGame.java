package Game;

import java.io.IOException;
import java.util.Scanner;

public class PlayGame {

	public static void main(String[] args) throws IOException {
		Scanner input = new Scanner(System.in);
		boolean gameOn = true;
		
		while (gameOn) {
			System.out.println("Welcome to...");
			System.out.println(
						  " ___                                 ___                          "
					+"\n"+"| . \\ _ _ ._ _  ___  ___  ___ ._ _  | . \\ _ _ ._ _ ._ _  ___  _ _" 
					+"\n"+"| | || | || ' |/ . |/ ._>/ . \\| ' | |   /| | || ' || ' |/ ._>| '_>"
					+"\n"+"|___/`___||_|_|\\_. |\\___.\\___/|_|_| |_\\_\\`___||_|_||_|_|\\___.|_|"  
					+"\n"+"               <___\'                                              "
			);
			System.out.println("Press Any Key to continue...");
			prompt(input);
			
			System.out.println("Please enter your name: ");
			String name = prompt(input); //Mighty Thor
			
			System.out.println("Please enter something about yourself: ");
			String description = prompt(input); //a musclebound hulk intent on crushing all evil in his way

			
			StartAdventure game = new StartAdventure(new Player(name, description, 40, 6, 20, 10), new Dungeon(), input);
			
			gameOn = false;
		}
	}
	
	//Utility
	private static String prompt(Scanner scanner) {
		return scanner.nextLine();
	}
}
