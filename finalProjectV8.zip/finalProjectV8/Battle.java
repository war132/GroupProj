package Game;

import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;


public final class Battle {

	public Battle(Player player, Monster monster) throws IOException {
        System.out.println("You encounter a " + monster  + "\n");
        System.out.println("Battle with " + monster + " starts (" + player.getHealth() + " / " + monster.getHealth()
		+ ") " + "Gems: " + player.getGemCount());
        
        Scanner scanner;
        while (player.isAlive() && monster.isAlive()) {
            System.out.print("\n Attack (1) or heal (2)? \n");
            int action = -1;
            
            while(action != 1 || action != 2) {
           	 try { 
           		scanner = new Scanner(System.in);
           		action = scanner.nextInt();
           		break;
           	 }
           	 
           	 catch (InputMismatchException | NumberFormatException  a) {
                	System.out.println("WRONG INPUT, PLEASE TRY AGAIN(Enter 1 or 2)");
              }
           }
            
            while
            	( action != 1 && action != 2) {
            		System.out.println("Please enter 1 or 2");
            			scanner = new Scanner(System.in);
            		action = scanner.nextInt();
            }
            
            if(action == 1) {
            	monster.defend(player);
            }
            
            else if (action == 2) {
                player.heal();
            } 
            
            if (monster.isAlive()) {
            		player.defend(monster);
            }
            
            else if (!(monster.isAlive())) {
                player.increaseGemCount();
                System.out.println(player.getInfo());
            }
            
        }
    }

}