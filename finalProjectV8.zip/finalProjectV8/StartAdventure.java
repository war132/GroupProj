package Game;

import java.io.IOException;
import java.util.Scanner;

public class StartAdventure {
	Player player;
	Dungeon dungeon;
	public StartAdventure(Player player, Dungeon dungeon, Scanner sc) throws IOException{
		boolean gameOn = true;
		
		//initialize player
		this.player = player;
		
		//initialize environment
		this.dungeon = dungeon;
		
		try {
			dungeon.movePlayer(player);
		} catch (IOException e) {
			e.printStackTrace();
		}
		do {
			if(!this.player.isAlive()) {
				System.out.println("GAME OVER! PRESS 1 TO RESTART");
				int selection = getUserInput(sc);
				Scanner input = new Scanner(System.in);
				System.out.println("Press Enter to continue...");
				prompt(input);
				
				System.out.println("Please enter your name: ");
				String name = prompt(input);
				
				StartAdventure game = new StartAdventure(new Player(name, 40, 5, 18, 10,0), new Dungeon(), input);
			
			}
			else if (player.getGemCount()==7) {
				gameOn = false;
				System.out.println("YOU WIN! PRESS 1 TO RESTART");
				int selection = getUserInput(sc);
				Scanner input = new Scanner(System.in);
				System.out.println("Press Enter to continue...");
				prompt(input);
				
				System.out.println("Please enter your name: ");
				String name = prompt(input);
				
				StartAdventure game = new StartAdventure(new Player(name, 40, 5, 18, 10,0), new Dungeon(), input);
	            
	        } 
			else {
				System.out.println("Enter 1 to continue");
				int selection = getUserInput(sc);
				handleUserSelection(selection);
			}
		} while(gameOn == true);
	}
		
	
	private static String prompt(Scanner scanner) {
		return scanner.nextLine();
	}
	
	private void handleUserSelection(int selection) throws IOException {
		switch (selection) {
			case 1: dungeon.movePlayer(player);
				break;
			case 2: dungeon.movePlayer(player);
				break;
			case 3: dungeon.movePlayer(player);
				break;
			case 4: dungeon.movePlayer(player);
				break;
			case 5: System.out.println(player.getInfo());
		}
	}
	
	private static int getUserInput(Scanner sc) {
		return sc.nextInt();
	}
}
