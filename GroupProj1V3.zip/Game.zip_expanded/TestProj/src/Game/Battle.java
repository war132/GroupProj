package Game;

import java.io.IOException;
import java.util.Scanner;


public final class Battle {

    public Battle(Player player, Monster monster) throws IOException {
        System.out.println("You encounter " + monster + ": " + monster.getDescription() + "\n");
        System.out.println("Battle with " + monster + " starts (" + player.getStatus() + " / "
                + monster.getStatus() + ")");
        Scanner in = new Scanner(System.in);
        while (player.isAlive() && monster.isAlive()) {
            System.out.print("Attack (1) or heal (2)? ");
            int action = in.nextInt();
            if (action == 2) {
                player.heal();
            } else {
                monster.defend(player);
            }
            if (monster.isAlive()) {
                player.defend(monster);
            }
        }
    }

}