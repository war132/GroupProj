package Game;

import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;


public final class Battle {

    public Battle(Player player, Monster monster) throws IOException {
    		
    		System.out.println("You encounter " + monster + "." + "\n");
        System.out.println("Battle with " + monster + " starts. (" + player.getStatus() + " / "
                + monster.getStatus() + ")");
        Scanner in = new Scanner(System.in);
        while (player.isAlive() && monster.isAlive()) {
            System.out.print("Attack (1) or heal (2)? ");
            int action = in.nextInt();
          
            // might need try/catch for type char instead of type int

            if (action == 1) {
            		monster.defend(player);
            }
            
            if (action == 2) {
            		player.heal();
            }

            if (action != 1 && action !=2) {
            		System.out.print("");
            }
            
            else if (monster.isAlive()) {
                player.defend(monster);
            }  
            
        }
    }

}