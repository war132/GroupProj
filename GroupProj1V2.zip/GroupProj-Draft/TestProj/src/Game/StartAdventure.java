package Game;

import java.io.IOException;
import java.util.Scanner;

public class StartAdventure {
	Player player;
	Dungeon dungeon;
	public StartAdventure(Player player, Dungeon dungeon, Scanner sc) throws IOException{
		
		//initialize player
		this.player = player;
		
		//initialize environment
		this.dungeon = dungeon;
		
		try {
			dungeon.movePlayer(player);
		} catch (IOException e) {
			e.printStackTrace();
		}
		/*
		System.out.println("Choose your direction => ");
		System.out.println("1. North" + "\n"
						+  "2. South" + "\n"
						+  "3. East" + "\n"
						+  "4. West" + "\n"
						+  "5. View Player Information");
		*/
		int selection = getUserInput(sc);
		handleUserSelection(selection);
	}
	
	private void handleUserSelection(int selection) throws IOException {
		switch (selection) {
			case 1: dungeon.movePlayer(player);
				break;
			case 2: dungeon.movePlayer(player);
				break;
			case 3: dungeon.movePlayer(player);
				break;
			case 4: dungeon.movePlayer(player);
				break;
			case 5: System.out.println(player.getInfo());
		}
	}
	
	private static int getUserInput(Scanner sc) {
		return sc.nextInt();
	}
}
