
package finalProject;

import java.io.IOException;
import java.util.Scanner;

public class PlayGame {

	public static void main(String[] args) throws IOException {
		Scanner input = new Scanner(System.in);
		boolean gameOn = true;
		
		while (gameOn) {
			System.out.println("Welcome to...");
			System.out.println("\n" + 
					" ██████╗ ███████╗███╗   ███╗███████╗     ██████╗ ███████╗    ███████╗██╗  ██╗ █████╗ ██████╗ ██╗ █████╗ \n" + 
					"██╔════╝ ██╔════╝████╗ ████║██╔════╝    ██╔═══██╗██╔════╝    ██╔════╝██║  ██║██╔══██╗██╔══██╗██║██╔══██╗\n" + 
					"██║  ███╗█████╗  ██╔████╔██║███████╗    ██║   ██║█████╗      ███████╗███████║███████║██████╔╝██║███████║\n" + 
					"██║   ██║██╔══╝  ██║╚██╔╝██║╚════██║    ██║   ██║██╔══╝      ╚════██║██╔══██║██╔══██║██╔══██╗██║██╔══██║\n" + 
					"╚██████╔╝███████╗██║ ╚═╝ ██║███████║    ╚██████╔╝██║         ███████║██║  ██║██║  ██║██████╔╝██║██║  ██║\n" + 
					" ╚═════╝ ╚══════╝╚═╝     ╚═╝╚══════╝     ╚═════╝ ╚═╝         ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝ ╚═╝╚═╝  ╚═╝\n" + 
					"                                                                                                        \n" + 
					""
			);
			System.out.println("The King of Shabia has asked you to return his gems to save the kingdom. Press Enter to Begin Your Adventure...");
			prompt(input);
			
			System.out.println("What is your name adventurer?");
			String name = prompt(input); 
			
			System.out.println("Please enter something about yourself: ");
			String description = prompt(input); 
			
			StartAdventure game = new StartAdventure(new Player(name, description, 40, 6, 20, 10,0), new Dungeon(), input);
			
			gameOn = false;
		}
	}
	
	
	//Utility
	private static String prompt(Scanner scanner) {
		return scanner.nextLine();
	}
}
