package finalProject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;


public final class Dungeon {

    private final Map<Integer, Map<Integer, Room>> map = new HashMap<Integer, Map<Integer, Room>>();
    private Room currentRoom;
    private int currentX = 0;
    private int currentY = 0;

    public Dungeon() {
    	//This is where we create our rooms that are part of the dungeon
        this.putRoom(0, 0, Room.newRegularInstance());
        this.putRoom(-1, 1, Room.newRegularInstance());
        this.putRoom(0, 1, Room.newRegularInstance());
        this.putRoom(1, 1, Room.newRegularInstance());
        this.putRoom(-1, 2, Room.newRegularInstance());
        this.putRoom(1, 2, Room.newRegularInstance());
        this.putRoom(-1, 3, Room.newRegularInstance());
        this.putRoom(0, 3, Room.newRegularInstance());
        this.putRoom(1, 3, Room.newRegularInstance());
        this.putRoom(0, 4, Room.newBossInstance());
        this.currentRoom = this.getRoom(0, 0);
    }

    private void putRoom(int x, int y, Room room) {
        if (!map.containsKey(x)) {
            map.put(x, new HashMap<Integer, Room>());
        }
        map.get(x).put(y, room);
    }

    private Room getRoom(int x, int y) {
        return map.get(x).get(y);
    }

    private boolean roomExists(int x, int y) {
        if (!map.containsKey(x)) {
            return false;
        }
        return map.get(x).containsKey(y);
    }

    private boolean isComplete() {
        return currentRoom.isBossRoom() && currentRoom.isComplete();
    }

    @SuppressWarnings("resource")
	public void movePlayer(Player player) throws IOException {
        boolean northPossible = roomExists(currentX, currentY + 1);
        boolean southPossible = roomExists(currentX, currentY - 1);
        boolean eastPossible = roomExists(currentX + 1, currentY);
        boolean westPossible = roomExists(currentX - 1, currentY);
        System.out.println("Where would you like to go: " + "\n");
        if (northPossible) {
            System.out.println("1. North (1)");
        }
        if (eastPossible) {
            System.out.println("2. East (2)");
        }
        if (southPossible) {
            System.out.println("3. South (3)");
        }
        if (westPossible) {
            System.out.println("4. West (4)");
        }
        System.out.println("5. View Player Info");
        System.out.println("6. Quit Game");
        Scanner scanner;
        int selection = 0;
        while(true) {
        	 try {
        		scanner = new Scanner(System.in);
             	selection = scanner.nextInt();
             	break;
             } catch (InputMismatchException | NumberFormatException  a) {
             	System.out.println("WRONG INPUT, PLEASE TRY AGAIN(HAVE TO PRESS A NUMBER)");
             }
        }
        if (selection == 1 && northPossible) {
            currentY++;
        } else if (selection == 2 && southPossible) {
            currentY--;
        } else if (selection == 3 && eastPossible) {
            currentX++;
        } else if (selection == 4 && westPossible) {
            currentX--;
        } else if (selection == 5) {
        	System.out.println(player.getInfo());
        } else if (selection == 6) {
        	System.exit(0);
        }
        currentRoom = getRoom(currentX, currentY);
        currentRoom.enter(player);
    }

    public void startQuest(Player player) throws IOException {
        while (player.isAlive() && !isComplete()) {
            movePlayer(player);
        }
        
        if (player.getGemCount()==5) {
            System.out.println( "You win!" );
        } else {
        	 BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        	System.out.print("Play Again? (Y) or (N) ");
            String action = in.readLine();
            if (action.equals("Y")) {
            	System.out.print("");
            } else {
                System.out.print("Game Over");
            } 
        }
    }
}
