package finalProject;

import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;


public final class Battle {

	public Battle(Player player, Monster monster) throws IOException {
        System.out.println("You encounter a " + monster  + "\n");
        System.out.println("Battle with " + monster + " starts (" + player.getHealth() + " / "
                + monster.getHealth() + ")");
        Scanner scanner;
        while (player.isAlive() && monster.isAlive()) {
            System.out.print("Attack (1) or heal (2)? ");
            int action = -1;
            while(action != 1 || action != 2) {
           	 try {
           		scanner = new Scanner(System.in);
           		action = scanner.nextInt();
           		break;
                } catch (InputMismatchException | NumberFormatException  a) {
                	System.out.println("WRONG INPUT, PLEASE TRY AGAIN(HAVE TO PRESS A NUMBER)");
                }
           }
            if (action == 2) {
                player.heal();
            } else if(action == 1) {
                monster.defend(player);
            }
            if (monster.isAlive()) {
                player.defend(monster);
            }
            if (!(monster.isAlive())) {
                player.increaseGemCount();
            }
        }
    }

}