package Game;

import java.io.IOException;
import java.util.Scanner;

public class StartAdventure {
	Player player;
	Dungeon dungeon;
	public StartAdventure(Player player, Dungeon dungeon, Scanner sc) throws IOException{
		
		//initialize player
		this.player = player;
		
		//initialize environment
		this.dungeon = dungeon;
		
		try {
			dungeon.movePlayer(player);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		while(true) {
			if(!this.player.isAlive()) {
				System.out.println("PRESS 1 TO RESTART");
				int selection = getUserInput(sc);
				Scanner input = new Scanner(System.in);
				System.out.println("Press Enter to continue...");
				prompt(input);
				
				System.out.println("Please enter your name: ");
				String name = prompt(input);
				
				System.out.println("Please enter something about yourself: ");
				String description = prompt(input); 
				StartAdventure game = new StartAdventure(new Player(name, description, 40, 6, 20, 10,0), new Dungeon(), input);
			}
			else {
				System.out.println("Enter 1 to continue");
				int selection = getUserInput(sc);
				handleUserSelection(selection);
			}
		}
	}
	private static String prompt(Scanner scanner) {
		return scanner.nextLine();
	}
	
	private void handleUserSelection(int selection) throws IOException {
		switch (selection) {
			case 1: dungeon.movePlayer(player);
				break;
			case 2: dungeon.movePlayer(player);
				break;
			case 3: dungeon.movePlayer(player);
				break;
			case 4: dungeon.movePlayer(player);
				break;
			case 5: System.out.println(player.getInfo());
		}
	}
	
	private static int getUserInput(Scanner sc) {
		return sc.nextInt();
	}
}
