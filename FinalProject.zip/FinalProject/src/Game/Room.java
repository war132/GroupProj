package Game;
import java.io.IOException;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public final class Room {

    private final String description;
    private final Monster monster;
    private final Boolean isBossRoom;
    private final static Random random = new Random();
    private final static Set<Integer> roomsSeen = new HashSet<Integer>();
    private final static int NUM_ROOMS = 7;

    private Room(String description, Monster monster, Boolean isBossRoom) {
        this.description = description;
        this.monster = monster;
        this.isBossRoom = isBossRoom;
    }

    public static Room newRegularInstance() {
        if (roomsSeen.size() == NUM_ROOMS) {
            roomsSeen.clear();
        }
        int i;
        do {
            i = random.nextInt(NUM_ROOMS);
        } while (roomsSeen.contains(i));
        roomsSeen.add(i);

        String roomDescription = null;
       if (i == 1) {
            roomDescription = "a long hallway with a pack of mutant rats feasting on a corpse";
        } else if (i == 2) {
            roomDescription = "a torture cell with torture instruments covering the walls";
        } else if (i == 3) {
            roomDescription = "the mess hall of the prison ";
        } else if (i == 4) {
            roomDescription =
                    "the head guards hideout  ";
        } else if (i == 5) {
            roomDescription =
                    "an open room with skeletons littering the floor";
        } else if (i == 6) {
            roomDescription = "a staircase that leads to the outside of the prison";
        }
        return new Room(roomDescription, Monster.newRandomInstance(), false);
    }

    public static Room newBossInstance() {
        return new Room("a huge cavern thick with the smell of sulfur", Monster.newBossInstance(),
                true);
    }

    public boolean isBossRoom() {
        return isBossRoom;
    }

    public boolean isComplete() {
        return !monster.isAlive();
    }

    @Override
    public String toString() {
        return description;
    }

    public void enter(Player player) throws IOException {
        System.out.println("You are in " + description);
        if (monster.isAlive()) {
            new Battle(player, monster);
        }
    }

}
