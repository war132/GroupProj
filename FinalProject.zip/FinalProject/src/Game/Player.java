package Game;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

public final class Player extends PlayGame {

	private final String name;
	private final String description;
	private final int maxHitPoints;
	private int hitPoints;
	private int numPotions;
	private final int minDamage;
	private final int maxDamage;
	public int gemCount = 1;
	private final Random random = new Random();

	public Player(String name, String description, int maxHitPoints, int minDamage, int maxDamage, int numPotions, int gemCount) {
		this.name = name;
		this.description = description;
		this.maxHitPoints = maxHitPoints;
		this.minDamage = minDamage;
		this.maxDamage = maxDamage;
		this.numPotions = numPotions;
		this.hitPoints = maxHitPoints;
		this.gemCount = gemCount;
	}

	public int attack() {
		return random.nextInt(maxDamage - minDamage + 1) + minDamage;
	}

	public void defend(Monster monster) throws IOException {
		int attackStrength = monster.attack();
		hitPoints = (hitPoints > attackStrength) ? hitPoints - attackStrength : 0;
		System.out.printf("  " + name + " is hit for %d HP of damage (%s)\n", attackStrength, getHealth());
		if (hitPoints == 0) {
			System.out.println("  " + name + " has been defeated");
			
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
    		System.out.print("Play Again? (Y) or (N) ");
        String action = in.readLine();
        if (action.equalsIgnoreCase("Y")) {
       
        	//restart game here
        	System.out.println();
        	
        } else {
            System.exit(0);
        } 
		}
	}

	public void heal() {
		if (numPotions > 0) {
			hitPoints = Math.min(maxHitPoints, hitPoints + 20);
			System.out.printf("  %s drinks healing potion (%s, %d potions left)\n", name, getHealth(), --numPotions);
		} else {
			System.out.println("  You've exhausted your potion supply!");
		}
	}

	public boolean isAlive() {
		return hitPoints > 0;
	}

	public String getHealth() {
		return "Player HP: " + hitPoints;
	}

	@Override
	public String toString() {
		return name;
	}

	public String getDescription() {
		return description;
	}

	public String getInfo() {
		return "Name: " + this.toString() + "\n" + "Description: " + this.getDescription() + "\n" + this.getHealth()
				+ "\n" + "Gem count: " + this.getGemCount();
	}

	public int getGemCount() {
		return this.gemCount;
	}
	
	public void increaseGemCount() {
		gemCount++;
	}
}
