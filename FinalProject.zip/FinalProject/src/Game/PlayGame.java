package Game;

import java.io.IOException;
import java.util.Scanner;

public class PlayGame {

	public static void main(String[] args) throws IOException {
		Scanner input = new Scanner(System.in);
		boolean gameOn = true;
		
		while (gameOn) {
			System.out.println("Welcome to...");
			System.out.println("\n" + 
					" ██████╗ ███████╗███╗   ███╗███████╗     ██████╗ ███████╗    ███████╗██╗  ██╗ █████╗ ██████╗ ██╗ █████╗ \n" + 
					"██╔════╝ ██╔════╝████╗ ████║██╔════╝    ██╔═══██╗██╔════╝    ██╔════╝██║  ██║██╔══██╗██╔══██╗██║██╔══██╗\n" + 
					"██║  ███╗█████╗  ██╔████╔██║███████╗    ██║   ██║█████╗      ███████╗███████║███████║██████╔╝██║███████║\n" + 
					"██║   ██║██╔══╝  ██║╚██╔╝██║╚════██║    ██║   ██║██╔══╝      ╚════██║██╔══██║██╔══██║██╔══██╗██║██╔══██║\n" + 
					"╚██████╔╝███████╗██║ ╚═╝ ██║███████║    ╚██████╔╝██║         ███████║██║  ██║██║  ██║██████╔╝██║██║  ██║\n" + 
					" ╚═════╝ ╚══════╝╚═╝     ╚═╝╚══════╝     ╚═════╝ ╚═╝         ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝ ╚═╝╚═╝  ╚═╝\n" + 
					"                                                                                                        \n" + 
					""
			);
			System.out.println("You are a Knight in the Shabian Empire, with a special quest from the king to find mystical gems that hold untamed power. \n"
					+ "You received word from Imperial scouts that the King’s former Head Guard has stolen these gems and is now hiding out in an abandoned prison \n"
					+ "with the intent to sell these gems to a group of dark wizards. In the wrong hands, these gems can lead to the destruction of the entire kingdom. \n"
					+ "You must find all 10 gems and return it to the kingdom or the world as you know it will be doomed. \n" + 
					"\n" + "Press Enter to Begin Your Adventure...");
			prompt(input);
			
			System.out.println("What is your name, adventurer?");
			String name = prompt(input); 
			
			System.out.println("Please enter something about yourself: ");
			String description = prompt(input); 
			
			StartAdventure game = new StartAdventure(new Player(name, description, 40, 6, 20, 10,0), new Dungeon(), input);
			
			gameOn = false;
		}
	}
	
	
	//Utility
	private static String prompt(Scanner scanner) {
		return scanner.nextLine();
	}
}
